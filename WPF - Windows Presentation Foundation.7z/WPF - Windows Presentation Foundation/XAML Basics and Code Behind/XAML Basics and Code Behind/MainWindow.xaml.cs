﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XAML_Basics_and_Code_Behind
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // We can write our own code here.

            // Creating new grid
            Grid grid = new Grid();
            this.Content = grid;

            // Creating new button
            Button btn = new Button();
            btn.FontSize = 26;
            btn.Width = 150;
            btn.Height = 100;

            // Creating wrap panel.
            WrapPanel wrapPanel = new WrapPanel();

            // Creating new text block.
            TextBlock txt = new TextBlock();

            // Adding text to the text block.
            txt.Text = "Multi";

            // Color of text is done with the brushes tag
            txt.Foreground = Brushes.Blue;

            // Adding text to the WrapPanel (by Accessing it's children)
            wrapPanel.Children.Add(txt);

            // Adding 2 more text blocks to WrapPanel by assigning a new TextBlock to txt and adding new values.
            txt = new TextBlock();
            txt.Text = "Color";
            txt.Foreground = Brushes.Yellow;
            wrapPanel.Children.Add(txt);

            txt = new TextBlock();
            txt.Text = "Button";
            txt.Foreground = Brushes.Red;
            wrapPanel.Children.Add(txt);


            // Now need to add the WrapPanel to the Button and the Button to the grid.
            btn.Content = wrapPanel;
            grid.Children.Add(btn);

            // Before running code, make sure the grid is commented in the XAML file.
        }
    }
}
