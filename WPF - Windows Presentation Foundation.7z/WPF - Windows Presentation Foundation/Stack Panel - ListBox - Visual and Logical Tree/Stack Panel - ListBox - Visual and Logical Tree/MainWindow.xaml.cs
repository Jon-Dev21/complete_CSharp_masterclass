﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Stack_Panel___ListBox___Visual_and_Logical_Tree
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This method was created when we declared the property Click="Button_Click" in the XAML code.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // This line of code runs once the button is clicked. It displays a Message Box with the passed string.
            MessageBox.Show("Button was clicked");
            // When debugging, in the Autos you can click the magnifying glass icon and see the Visual and Logical Tree.
            // In there, you can peek at all the properties of each element in your code.
        }
    }
}
