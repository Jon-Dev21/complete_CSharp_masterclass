﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListBox_and_a_List_of_Current_Matches
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //Creating a list of matches
            List<Match> matches = new List<Match>();
            matches.Add(new Match() {Team1 = "Bayern Munich", Team2="Real Madrid", Score1 = 3, Score2=2, Completion=85 });
            matches.Add(new Match() { Team1 = "Liverpool F.C", Team2 = "F.C. Barcelona", Score1 = 0, Score2 = 2, Completion = 30 });
            matches.Add(new Match() { Team1 = "Manchester City F.C.", Team2 = "Atlético De madrid", Score1 = 1, Score2 = 1, Completion = 49 });
            matches.Add(new Match() { Team1 = "A.C. Milan", Team2 = "Inter Milan", Score1 = 4, Score2 = 2, Completion = 90 });
            matches.Add(new Match() { Team1 = "Chelsea F.C", Team2 = "Arsenal F.C", Score1 = 2, Score2 = 2, Completion = 70 });
            // Adding "matches" list to our listBox Items Source. (Adding matches to listbox)
            lbMatches.ItemsSource = matches;
        }

        /// <summary>
        ///  Method runs when button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // If the match selected is not null.
            if(lbMatches!= null)
            {
                // Selected Item is an object representinge the item selected in the ListBox.
                // Need to parse selected item as Match in order to access the properties.
                MessageBox.Show("Selected Match: " 
                    + (lbMatches.SelectedItem as Match).Team1 + " " +
                    (lbMatches.SelectedItem as Match).Score1 +" " +
                    (lbMatches.SelectedItem as Match).Score2 +" " +
                    (lbMatches.SelectedItem as Match).Team2 +" ");
            }
        }
    }

    // Creating new Class Match that will take care of classes.
    public class Match
    {
        public int Score1 { get; set; }
        public int Score2 { get; set; }
        public string Team1 { get; set; }
        public string Team2 { get; set; }
        public int Completion { get; set; }

    }
}
