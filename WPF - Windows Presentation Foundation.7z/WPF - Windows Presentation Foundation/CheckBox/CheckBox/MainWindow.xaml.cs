﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CheckBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void CboxAllCheckedChanged(object sender, RoutedEventArgs e)
        {
            if(cboxAllTopings.IsChecked == true)
            {
                cbSalami.IsChecked = true;
                cbMushrooms.IsChecked = true;
                cbMozarella.IsChecked = true;
                cbPepperoni.IsChecked = true;
                cbBacon.IsChecked = true;
                cbHam.IsChecked = true;
            }
        }

        private void CboxSingleCheckedChanged(object sender, RoutedEventArgs e)
        {
            // Assign null to the All Toppings checkbix
            cboxAllTopings.IsChecked = null;
            if ((cbSalami.IsChecked == true) && (cbMushrooms.IsChecked == true) && (cbMozarella.IsChecked == true) && (cbPepperoni.IsChecked == true) && (cbBacon.IsChecked == true) && (cbHam.IsChecked == true))
            {
                cboxAllTopings.IsChecked = true;
            }

            if ((cbSalami.IsChecked == false) && (cbMushrooms.IsChecked == false) && (cbMozarella.IsChecked == false) && (cbPepperoni.IsChecked == false) && (cbBacon.IsChecked == false) && (cbHam.IsChecked == false))
            {
                cboxAllTopings.IsChecked = false;
            }
        }
    }
}
